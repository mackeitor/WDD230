function lastModified(){
    document.write(document.lastModified);
}
    lastModified();

